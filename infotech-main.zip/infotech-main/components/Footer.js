import React from 'react'

const Footer = () => {
  return (
    <footer>
      <p>
      &copy; 2022 WriteSpace. All Rights Reserved.
      </p>
    </footer>
  )
}

export default Footer